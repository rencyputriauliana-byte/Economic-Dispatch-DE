from pathlib import Path
import numpy as np
import pandas as pd
import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt

# Folder proyek: file Python dan Excel harus berada dalam folder yang sama.
FOLDER = Path(__file__).resolve().parent
INPUT_FILE = FOLDER / "Input_Data_DE.xlsx"

# Parameter Differential Evolution
F = 0.8       # Mutation Factor
CR = 0.9      # Crossover Rate

# ==================================================
# 1. MEMBACA DATA EXCEL
# ==================================================
units = pd.read_excel(INPUT_FILE, sheet_name="Units")
parameters = pd.read_excel(INPUT_FILE, sheet_name="Parameter")
param = dict(zip(parameters["Parameter"].astype(str).str.strip(),
                 parameters["Nilai"]))

pmin = units["Pmin (MW)"].to_numpy(dtype=float)
pmax = units["Pmax (MW)"].to_numpy(dtype=float)
a = units["a"].to_numpy(dtype=float)
b = units["b"].to_numpy(dtype=float)
c = units["c"].to_numpy(dtype=float)

Pd = float(param["Load demand (MW)"])
max_iter = int(param["Jumlah iterasi"])
population_size = int(param["Population Size"])
seed = int(param["Random seed"])
loss_coeff = np.array([
    float(param["Loss Unit 1"]),
    float(param["Loss Unit 2"]),
    float(param["Loss Unit 3"])
])
rng = np.random.default_rng(seed)

if population_size < 4:
    raise ValueError("Population Size minimal 4 untuk strategi DE/rand/1/bin.")

# ==================================================
# 2. FUNGSI OBJEKTIF DAN KENDALA
# ==================================================
def total_cost(P):
    return np.sum(a + b * P + c * P**2)

def transmission_loss(P):
    return np.sum(loss_coeff * P**2)

def power_balance(P):
    return np.sum(P) - transmission_loss(P) - Pd

# Menghitung daya unit ketiga dari persamaan keseimbangan daya.
def make_solution(p1, p2):
    if not (pmin[0] <= p1 <= pmax[0] and pmin[1] <= p2 <= pmax[1]):
        return None

    k1, k2, k3 = loss_coeff
    C = Pd - p1 - p2 + k1 * p1**2 + k2 * p2**2
    discriminant = 1 - 4 * k3 * C

    if discriminant < 0:
        return None

    p3 = (2 * C) / (1 + np.sqrt(discriminant))
    if not (pmin[2] <= p3 <= pmax[2]):
        return None

    P = np.array([p1, p2, p3])
    if abs(power_balance(P)) > 1e-5:
        return None
    return P

# ==================================================
# 3. INISIALISASI POPULASI
# ==================================================
population = []
max_attempts = 1_000_000

for _ in range(max_attempts):
    candidate = make_solution(
        rng.uniform(pmin[0], pmax[0]),
        rng.uniform(pmin[1], pmax[1])
    )
    if candidate is not None:
        population.append(candidate[:2])
    if len(population) == population_size:
        break

if len(population) < population_size:
    raise RuntimeError("Tidak berhasil membentuk populasi feasible. Periksa data input.")

population = np.asarray(population, dtype=float)

# ==================================================
# 4. OPTIMASI DIFFERENTIAL EVOLUTION
# Strategi: DE/rand/1/bin
# ==================================================
convergence = []
global_best = None
global_best_cost = np.inf

for generation in range(max_iter):
    for i in range(population_size):
        choices = [j for j in range(population_size) if j != i]
        r1, r2, r3 = rng.choice(choices, size=3, replace=False)

        # Mutasi
        mutant = population[r1] + F * (population[r2] - population[r3])
        mutant = np.clip(mutant, pmin[:2], pmax[:2])

        # Crossover binomial
        trial = population[i].copy()
        jrand = rng.integers(0, 2)
        for j in range(2):
            if rng.random() < CR or j == jrand:
                trial[j] = mutant[j]

        trial_solution = make_solution(trial[0], trial[1])
        target_solution = make_solution(population[i, 0], population[i, 1])

        # Seleksi: solusi harus feasible dan memiliki biaya lebih rendah.
        if (trial_solution is not None and
                total_cost(trial_solution) < total_cost(target_solution)):
            population[i] = trial

    feasible = [make_solution(ind[0], ind[1]) for ind in population]
    generation_best = min(feasible, key=total_cost)
    generation_cost = total_cost(generation_best)

    if generation_cost < global_best_cost:
        global_best = generation_best.copy()
        global_best_cost = generation_cost

    convergence.append(global_best_cost)

    if (generation + 1) % 100 == 0:
        print(f"Generasi {generation + 1}/{max_iter} | "
              f"Biaya terbaik = {global_best_cost:.6f}")

# ==================================================
# 5. MENAMPILKAN HASIL
# ==================================================
best_P = global_best
unit_cost = a + b * best_P + c * best_P**2
total_generation = np.sum(best_P)
total_loss = transmission_loss(best_P)
balance_error = power_balance(best_P)

print("\n========== HASIL OPTIMASI DE ==========")
for i, power in enumerate(best_P):
    print(f"Unit {i + 1}: {power:.4f} MW | Biaya = {unit_cost[i]:.4f}")
print("---------------------------------------")
print(f"Total Beban        : {Pd:.4f} MW")
print(f"Total Pembangkitan : {total_generation:.4f} MW")
print(f"Rugi Transmisi     : {total_loss:.4f} MW")
print(f"Total Biaya        : {global_best_cost:.6f}")
print(f"Error Keseimbangan : {balance_error:.10f} MW")

# ==================================================
# 6. MENYIMPAN HASIL EXCEL DAN GRAFIK
# ==================================================
dispatch = pd.DataFrame({
    "Unit": [f"Unit {i}" for i in range(1, len(best_P) + 1)],
    "Daya (MW)": best_P,
    "Biaya Pembangkitan": unit_cost,
    "Pmin (MW)": pmin,
    "Pmax (MW)": pmax
})
summary = pd.DataFrame({
    "Keterangan": [
        "Load Demand (MW)", "Total Generation (MW)",
        "Transmission Loss (MW)", "Total Cost",
        "Power Balance Error (MW)", "Mutation Factor (F)",
        "Crossover Rate (CR)", "Population Size", "Jumlah Generasi"
    ],
    "Nilai": [
        Pd, total_generation, total_loss, global_best_cost,
        balance_error, F, CR, population_size, max_iter
    ]
})
convergence_df = pd.DataFrame({
    "Generasi": np.arange(1, max_iter + 1),
    "Biaya Terbaik": convergence
})

output_excel = FOLDER / "output_data_DE.xlsx"
with pd.ExcelWriter(output_excel, engine="openpyxl") as writer:
    dispatch.to_excel(writer, sheet_name="Dispatch Results", index=False)
    summary.to_excel(writer, sheet_name="Summary", index=False)
    convergence_df.to_excel(writer, sheet_name="Convergence", index=False)

plt.figure(figsize=(10, 5))
plt.plot(np.arange(1, max_iter + 1), convergence)
plt.title("Konvergensi Optimasi Differential Evolution (DE)")
plt.xlabel("Generasi")
plt.ylabel("Total Biaya Pembangkitan")
plt.grid(True)
plt.tight_layout()
graph_file = FOLDER / "grafik_konvergensi_DE.png"
plt.savefig(graph_file, dpi=300)
plt.close()

print("\nFile hasil tersimpan:")
print(output_excel)
print(graph_file)
