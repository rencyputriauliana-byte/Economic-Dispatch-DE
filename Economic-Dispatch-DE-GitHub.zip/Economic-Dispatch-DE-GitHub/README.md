# Economic Dispatch dengan Differential Evolution (DE)

Program optimasi Economic Dispatch untuk tiga unit pembangkit dengan
memperhitungkan batas daya generator dan rugi transmisi.

## Isi repository
- `economic_dispatch_DE.py`: program optimasi DE.
- `Input_Data_DE.xlsx`: input generator dan parameter sistem.
- `requirements.txt`: pustaka Python.
- `.github/workflows/run-de.yml`: workflow menjalankan program di GitHub Actions.

## Menjalankan di komputer
Python 3.10 atau lebih baru direkomendasikan.

```bash
pip install -r requirements.txt
python economic_dispatch_DE.py
```

Program menghasilkan `output_data_DE.xlsx` dan `grafik_konvergensi_DE.png`.

## Menjalankan di GitHub
1. Buat repository baru di GitHub.
2. Upload semua file dan folder dari proyek ini.
3. Buka tab **Actions**.
4. Pilih **Run Economic Dispatch DE**.
5. Klik **Run workflow**.
6. Setelah workflow selesai, buka hasil run dan unduh artifact `hasil-optimasi-de`.

## Parameter DE
- Strategi: DE/rand/1/bin
- Population Size: 30 (dari Excel)
- Jumlah generasi: 1000 (dari Excel)
- Mutation Factor (F): 0.8
- Crossover Rate (CR): 0.9
- Random Seed: 42 (dari Excel)

F dan CR dapat diubah pada bagian awal file Python.
